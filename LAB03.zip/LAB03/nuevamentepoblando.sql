INSERT INTO carrera VALUES('LRS','LaRutaSabana','COLOMBIA',4,'A');
INSERT INTO punto VALUES('LRS',49,'cajica','C',4577.25,345);
INSERT INTO versioon VALUES('LRS','19CO',TO_DATE('2019/01/18','yyyy/mm/dd'));
INSERT INTO segmento VALUES('Sisga','LRS','C','LRS','LRS');
INSERT INTO miembro VALUES(145,'CC',45789787841,'COLOMBIA','TinTin@gmail.com');
INSERT INTO persona VALUES(145,'Tin Tin');
INSERT INTO ciclista VALUES(145,TO_DATE('1995/08/26','yyyy/mm/dd'),4);
INSERT INTO registro VALUES(5,TO_DATE('2018/08/26 09:53:14','YYYY/MM/DD HH24:MI:SS'),294,1,NULL,'M',145,'LRS','Sisga',NULL);

INSERT INTO carrera VALUES('LRS18CO','LaRutaSabana','COLOMBIA',4,'A');
INSERT INTO punto VALUES('LRS18CO',49,'cajica','C',4577.25,345);
INSERT INTO versioon VALUES('LRS18CO','18CO',TO_DATE('2019/01/18','yyyy/mm/dd'));
INSERT INTO segmento VALUES('Lacuchilla','LRS18CO','C','LRS18CO','LRS18CO');
INSERT INTO miembro VALUES(146,'CC',45989787841,'COLOMBIA','Tovar@gmail.com');
INSERT INTO persona VALUES(146,'Tovar');
INSERT INTO ciclista VALUES(146,TO_DATE('1995/08/26','yyyy/mm/dd'),4);
INSERT INTO registro VALUES(6,TO_DATE('2018/08/26 09:53:14','YYYY/MM/DD HH24:MI:SS'),294,2,NULL,'M',145,'LRS18CO','Lacuchilla',NULL);



insert into carrera (codigo, nombre, pais, categoria, periodicidad) values ('xh4voT', 'Vale', 'Colombia', 1, 'S');
insert into carrera (codigo, nombre, pais, categoria, periodicidad) values ('e6OZhfN4Va7b', 'Joycelin', '', 2, 'A');
insert into carrera (codigo, nombre, pais, categoria, periodicidad) values ('67VY8QR', 'Gaby', 'COLOMBIA', 3, 'B');
insert into carrera (codigo, nombre, pais, categoria, periodicidad) values ('V6L6', 'Melvyn', 'COSTA RICA', 4, 'A');
insert into carrera (codigo, nombre, pais, categoria, periodicidad) values ('V5rjt', 'Jacynth', 'COSATA RICA2', 5, 'T');
insert into carrera (codigo, nombre, pais, categoria, periodicidad) values ('0M1QX8Z', 'Suzanna', 'EsPA�A', 6, 'F');
insert into carrera (codigo, nombre, pais, categoria, periodicidad) values ('M7VDY', 'Jilly', 'INGLATERRA', 7, 'E');
insert into carrera (codigo, nombre, pais, categoria, periodicidad) values ('PIAB3M', 'Cthrine', 'rerf', 8, 'V');

insert into miembro (idd, idt, idn, pais_m, correo) values (58839, 'CE', 962588583491539, 'Peru', 'mpallister0@hibu.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (50533, 'CC', 789753033875393, 'China', 'fcoogan1@usa.gov');
insert into miembro (idd, idt, idn, pais_m, correo) values (98834, 'NT', 450439755912836, 'Czech Republic', 'imeany2@csmonitor.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (65925, 'NT', 382782887711447, 'Colombia', 'lpeltzer3@indiegogo.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (74604, 'NT', 362429641899349, 'Brazil', 'lbrownscombe4@usnews.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (12749, 'NT', 590678253054155, 'Russia', 'ohardey5@twitter.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (77568, 'CC', 478462189890911, 'United States', 'ndoorey6@cargocollective.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (75446, 'CE', 748174149290060, 'Japan', 'njenicke7@hugedomains.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (505, 'NT', 391376315528211, 'Albania', 'xaubert0@imageshack.us');
insert into miembro (idd, idt, idn, pais_m, correo) values (2567, 'CE', 704792822061539, 'Honduras', 'mgooddy1@vinaora.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (1789, 'NT', 284856432012815, 'Philippines', 'ohefford2@google.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (7705, 'CC', 80939054426157, 'China', 'hhathorn3@yahoo.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (8185, 'CE', 282701536930809, 'Russia', 'vbroz4@ca.gov');
insert into miembro (idd, idt, idn, pais_m, correo) values (6604, 'CC', 30836313476645, 'Russia', 'hpury5@hostgator.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (9173, 'NT', 560020323809339, 'Indonesia', 'mfuchs6@networksolutions.com');
insert into miembro (idd, idt, idn, pais_m, correo) values (5584, 'NT', 271109417989104, 'China', 'gpaschke7@clickbank.net');

insert into propiedad_de (propietario, carrera_cod, porcentaje) values (58839, 'xh4voT', 56);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (50533, 'e6OZhfN4Va7b', 79);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (98834, '67VY8QR', 59);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (65925, 'V6L6', 11);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (74604, 'V5rjt', 41);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (12749, '0M1QX8Z', 3);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (77568, 'PIAB3M', 17);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (75446, 'M7VDY', 55);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (5584, 'xh4voT', 56);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (9173, 'e6OZhfN4Va7b', 79);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (6604, '67VY8QR', 59);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (8185, 'V6L6', 11);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (7705, 'V5rjt', 41);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (1789, '0M1QX8Z', 3);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (2567, 'PIAB3M', 17);
insert into propiedad_de (propietario, carrera_cod, porcentaje) values (505, 'M7VDY', 55);

insert into punto (punto_carrera, orden, nombre, tipo, distancia, tiempo_limite) values ('xh4voT', 8, 'asd', 1, 6514854.22, 74655);
insert into punto (punto_carrera, orden, nombre, tipo, distancia, tiempo_limite) values ('e6OZhfN4Va7b', 88, 'dsa', 2, 94554989.05, 47936);
insert into punto (punto_carrera, orden, nombre, tipo, distancia, tiempo_limite) values ('67VY8QR', 62, 'qwe', 3, 30933360.02, 15070);
insert into punto (punto_carrera, orden, nombre, tipo, distancia, tiempo_limite) values ('V6L6', 8, 'qrf', 4, 34515457.78, 20929);
insert into punto (punto_carrera, orden, nombre, tipo, distancia, tiempo_limite) values ('V5rjt', 34, 'fff', 5, 68500514.9, 46745);
insert into punto (punto_carrera, orden, nombre, tipo, distancia, tiempo_limite) values ('M7VDY', 15, 'qwd', 6, 74049252.02, 5173);
insert into punto (punto_carrera, orden, nombre, tipo, distancia, tiempo_limite) values ('0M1QX8Z', 93, 'hgf', 7, 20803330.03, 15147);
insert into punto (punto_carrera, orden, nombre, tipo, distancia, tiempo_limite) values ('PIAB3M', 65, 'cxz', 8, 31030804.7, 84228);

insert into versioon (carrera_ver, nombre, fecha) values ('xh4voT', 'NK30', TO_DATE('2019/07/21','yyyy/mm/dd'));
insert into versioon (carrera_ver, nombre, fecha) values ('e6OZhfN4Va7b', 'GJa4', TO_DATE('2018/11/27','yyyy/mm/dd'));
insert into versioon (carrera_ver, nombre, fecha) values ('67VY8QR', 'PLx3', TO_DATE('2018/12/27','yyyy/mm/dd'));
insert into versioon (carrera_ver, nombre, fecha) values ('V6L6', 'BTl6', TO_DATE('2019/04/19','yyyy/mm/dd'));
insert into versioon (carrera_ver, nombre, fecha) values ('M7VDY', 'NWt9', TO_DATE('2019/03/22','yyyy/mm/dd'));
insert into versioon (carrera_ver, nombre, fecha) values ('V5rjt', 'ZOl6', TO_DATE('2019/09/17','yyyy/mm/dd'));
insert into versioon (carrera_ver, nombre, fecha) values ('0M1QX8Z', 'LHy7', TO_DATE('2018/12/10','yyyy/mm/dd'));
insert into versioon (carrera_ver, nombre, fecha) values ('PIAB3M', 'OFr3', TO_DATE('2019/02/25','yyyy/mm/dd'));

insert into segmento (nombre, seg_version, tipo_seg, punto_ini, punto_fin) values ('casa', 'xh4voT', 'C', 'xh4voT', 'PIAB3M');
insert into segmento (nombre, seg_version, tipo_seg, punto_ini, punto_fin) values ('marca', 'e6OZhfN4Va7b', 'M', 'e6OZhfN4Va7b', 'e6OZhfN4Va7b');
insert into segmento (nombre, seg_version, tipo_seg, punto_ini, punto_fin) values ('lisa', '67VY8QR', 'M', '67VY8QR', 'V6L6');
insert into segmento (nombre, seg_version, tipo_seg, punto_ini, punto_fin) values ('baja', 'V6L6', 'L', 'V6L6', '67VY8QR');
insert into segmento (nombre, seg_version, tipo_seg, punto_ini, punto_fin) values ('sube', 'M7VDY', 'M', 'M7VDY', 'PIAB3M');
insert into segmento (nombre, seg_version, tipo_seg, punto_ini, punto_fin) values ('playa', 'V5rjt', 'C', 'V5rjt', 'PIAB3M');
insert into segmento (nombre, seg_version, tipo_seg, punto_ini, punto_fin) values ('rio', '0M1QX8Z', 'M', '0M1QX8Z', 'PIAB3M');
insert into segmento (nombre, seg_version, tipo_seg, punto_ini, punto_fin) values ('calle', 'PIAB3M', 'L', 'PIAB3M', 'V6L6');

insert into persona (persona_id, nombre) values (58839, 'Tommi Job');
insert into persona (persona_id, nombre) values (50533, 'Carlin Citrine');
insert into persona (persona_id, nombre) values (2567, 'Baudoin Goldie');
insert into persona (persona_id, nombre) values (7705, 'Caryn Lanfere');
insert into persona (persona_id, nombre) values (8185, 'Tiffy Ownsworth');
insert into persona (persona_id, nombre) values (6604, 'Durand Tatum');
insert into persona (persona_id, nombre) values (77568, 'Emory Dwelley');
insert into persona (persona_id, nombre) values (75446, 'Rockey Purcell');

insert into empresa (empresa_id, razon_social, persona_idd) values (12749, 'cuidado de ancianos', 'Gawain Pillman');
insert into empresa (empresa_id, razon_social, persona_idd) values (74604, 'cuidado de animales callejeros', 'Maren Ahlin');
insert into empresa (empresa_id, razon_social, persona_idd) values (65925, 'limpieza a parques', 'Jehanna Elstob');
insert into empresa (empresa_id, razon_social, persona_idd) values (98834, 'implementos a personas en discapacidad', 'Norri Napton');
insert into empresa (empresa_id, razon_social, persona_idd) values (5584, 'cuidado de ancianos', 'Petronella Dummer');
insert into empresa (empresa_id, razon_social, persona_idd) values (9173, 'limpieza a parques', 'Ingeberg Birkett');
insert into empresa (empresa_id, razon_social, persona_idd) values (1789, 'cuidado de animales', 'Hildy Schleswig-Holstein');
insert into empresa (empresa_id, razon_social, persona_idd) values (505, 'cuidado de animales', 'Andeee Schuchmacher');

insert into empver (empre_id, carrera_ver1) values (12749, 'xh4voT');
insert into empver (empre_id, carrera_ver1) values (74604, 'e6OZhfN4Va7b');
insert into empver (empre_id, carrera_ver1) values (65925, '67VY8QR');
insert into empver (empre_id, carrera_ver1) values (98834, 'V6L6');
insert into empver (empre_id, carrera_ver1) values (5584, 'M7VDY');
insert into empver (empre_id, carrera_ver1) values (9173, 'V5rjt');
insert into empver (empre_id, carrera_ver1) values (1789, '0M1QX8Z');
insert into empver (empre_id, carrera_ver1) values (505, 'PIAB3M');

insert into ciclista (ciclista_id, nacimiento, categoria) values (58839, TO_DATE('2000/01/25','yyyy/mm/dd'), 2);
insert into ciclista (ciclista_id, nacimiento, categoria) values (50533, TO_DATE('1996/04/27','yyyy/mm/dd'), 5);
insert into ciclista (ciclista_id, nacimiento, categoria) values (2567, TO_DATE('1997/09/08','yyyy/mm/dd'), 3);
insert into ciclista (ciclista_id, nacimiento, categoria) values (7705, TO_DATE('1997/04/17','yyyy/mm/dd'), 2);
insert into ciclista (ciclista_id, nacimiento, categoria) values (8185, TO_DATE('1994/05/10','yyyy/mm/dd'), 5);
insert into ciclista (ciclista_id, nacimiento, categoria) values (6604, TO_DATE('1994/01/29','yyyy/mm/dd'), 1);
insert into ciclista (ciclista_id, nacimiento, categoria) values (77568, TO_DATE('1997/12/03','yyyy/mm/dd'), 5);
insert into ciclista (ciclista_id, nacimiento, categoria) values (75446, TO_DATE('1996/10/01','yyyy/mm/dd'), 2);

insert into ciclver (cicli_id, carrera_ver2) values (58839, 'xh4voT');
insert into ciclver (cicli_id, carrera_ver2) values (50533, 'e6OZhfN4Va7b');
insert into ciclver (cicli_id, carrera_ver2) values (2567, '67VY8QR');
insert into ciclver (cicli_id, carrera_ver2) values (7705, 'V6L6');
insert into ciclver (cicli_id, carrera_ver2) values (8185, 'M7VDY');
insert into ciclver (cicli_id, carrera_ver2) values (6604, 'V5rjt');
insert into ciclver (cicli_id, carrera_ver2) values (77568, '0M1QX8Z');
insert into ciclver (cicli_id, carrera_ver2) values (75446, 'PIAB3M');

insert into registro (numero, fecha, teimpo, posicion, revision, dificultad, c_registro, ver_registro, seg_registro, comentario) values (7, TO_DATE('2018-05-17 08:22:51','yyyy/mm/dd hh24:mi'), 879, 54, NULL, 'A', 58839, 'xh4voT', 'casa', 'Sube facil');
insert into registro (numero, fecha, teimpo, posicion, revision, dificultad, c_registro, ver_registro, seg_registro, comentario) values (8, TO_DATE('2018-07-01 14:36:22','yyyy/mm/dd hh24:mi'), 887, 134, 'la velocidad minima es de 4 km/h y la maxima de 15km/h', 'A', 50533, 'e6OZhfN4Va7b', 'casa', NULL);
insert into registro (numero, fecha, teimpo, posicion, revision, dificultad, c_registro, ver_registro, seg_registro, comentario) values (9, TO_DATE('2018-06-22 23:04:46','yyyy/mm/dd hh24:mi'), 714, 156, NULL, 'M', 2567, '67VY8QR', 'lisa', NULL);
insert into registro (numero, fecha, teimpo, posicion, revision, dificultad, c_registro, ver_registro, seg_registro, comentario) values (10, TO_DATE('2017-12-14 19:57:30','yyyy/mm/dd hh24:mi'), 568, 199, NULL, 'A', 7705, 'V6L6', 'casa', 'bajda rapida');
insert into registro (numero, fecha, teimpo, posicion, revision, dificultad, c_registro, ver_registro, seg_registro, comentario) values (11, TO_DATE('2018-04-22 16:32:16','yyyy/mm/dd hh24:mi'), 300, 127, 'tiene 205 pulsaciones por segundo', 'B', 8185, 'M7VDY', 'playa', NULL);
insert into registro (numero, fecha, teimpo, posicion, revision, dificultad, c_registro, ver_registro, seg_registro, comentario) values (12, TO_DATE('2018-02-03 11:59:37','yyyy/mm/dd hh24:mi'), 958, 180, NULL, 'A', 6604, 'V5rjt', 'casa', 'se gira el manubrio');
insert into registro (numero, fecha, teimpo, posicion, revision, dificultad, c_registro, ver_registro, seg_registro, comentario) values (13, TO_DATE('2018-04-01 02:18:55','yyyy/mm/dd hh24:mi'), 848, 44, NULL, 'M', 77568, '0M1QX8Z', 'lisa', NULL);
insert into registro (numero, fecha, teimpo, posicion, revision, dificultad, c_registro, ver_registro, seg_registro, comentario) values (14, TO_DATE('2018-08-15 04:14:58','yyyy/mm/dd hh24:mi'), 123, 71, 'el tramo en subida lo tuvo muy dificil', 'B', 75446, 'PIAB3M', 'playa', NULL);

insert into foto(numero,direccion) values (7,NULL);
insert into foto(numero,direccion) values (8,NULL);
insert into foto(numero,direccion) values (9,'www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwj407acwO_kAhVIrlkKHQ5xApEQjRx6BAgBEAQ&url=http%3A%2F%2Felciclismoencolombia.wikidot.com%2Fvuelta-a-colombia&psig=AOvVaw0HwgQh4Hj1GxicrtG6QW7m&ust=1569622044279248.gif');
insert into foto(numero,direccion) values (10,NULL);
insert into foto(numero,direccion) values (11,NULL);
insert into foto(numero,direccion) values (12,NULL);
insert into foto(numero,direccion) values (13, 'www.gifmania.com/Gif-Animados-Deportes/Imagenes-Ciclismo/Ciclistas/Ciclista-87408.gif');
insert into foto(numero,direccion) values (14,NULL);