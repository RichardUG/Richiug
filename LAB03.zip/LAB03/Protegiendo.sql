/*Atributos*/
ALTER TABLE carrera ADD CONSTRAINT carrera_ck CHECK(REGEXP_LIKE(codigo,'^([A-Z0-9]*)$')AND REGEXP_LIKE(pais,'^([A-Z]*|\s)$') AND (pais LIKE('% %') OR pais NOT LIKE('% %')) AND categoria>=1 AND categoria<=5 AND (periodicidad='A' OR periodicidad='S' OR periodicidad='T' OR periodicidad='B'));
ALTER TABLE punto ADD CONSTRAINT punto_ck CHECK(UPPER(punto_carrera)=punto_carrera AND REGEXP_LIKE(punto_carrera,'^([A-Z0-9]*)$') AND (tipo='P' OR tipo='L' OR tipo='H' OR tipo='A' OR tipo='M' OR tipo='V' OR tipo='C') AND tiempo_limite>0);
ALTER TABLE propiedad_de ADD CONSTRAINT propiedad_de_ck CHECK(propieterio>=1 AND propieterio<=99999 AND UPPER(carrera_cod)=carrera_cod AND REGEXP_LIKE(carrera_cod,'^([A-Z0-9]*)$') AND porcentaje>=0 AND porcentaje<=100);

ALTER TABLE versioon ADD CONSTRAINT versioonn_ck CHECK(UPPER(carrera_ver)=carrera_ver AND REGEXP_LIKE(carrera_ver,'^([A-Z0-9]*)$'));
ALTER TABLE segmento ADD CONSTRAINT segmento_ck CHECK(UPPER(seg_version)=seg_version AND REGEXP_LIKE(seg_version,'^([A-Z0-9]*)$') AND (tipo_seg='C' OR tipo_seg='M' OR tipo_seg='L') AND UPPER(punto_ini)=punto_ini AND REGEXP_LIKE(punto_ini,'^^([A-Z0-9]*)$') AND UPPER(punto_fin)=punto_fin AND REGEXP_LIKE(punto_fin,'^([A-Z0-9]*)$') );

ALTER TABLE miembro ADD CONSTRAINT miembro_ck CHECK(idd>=1 AND idd<=99999 AND (idt='CC' OR idt='CE' OR idt='NT') AND idn>1111111111 AND REGEXP_LIKE(pais_m,'^([A-Z]*|\s)$') AND REGEXP_LIKE(correo,'^[a-zA-Z0-9]+@[a-zA-Z0-9]'));
ALTER TABLE persona ADD CONSTRAINT persona_ck CHECK(persona_id>=1 AND persona_id<=99999);
ALTER TABLE empresa ADD CONSTRAINT empresa_ck CHECK(empresa_id>=1 AND empresa_id<=99999 AND persona_idd>=1 AND persona_idd<=99999);
ALTER TABLE ciclista ADD CONSTRAINT ciclista_ck CHECK(ciclista_id>=1 AND ciclista_id<=99999 AND categoria>=1 AND categoria<=5);
ALTER TABLE empver ADD CONSTRAINT empver_ck CHECK(empre_id>=1 AND empre_id<=99999 AND UPPER(carrera_ver1)=carrera_ver1 AND REGEXP_LIKE(carrera_ver1,'^([A-Z0-9]*)$'));
ALTER TABLE ciclver ADD CONSTRAINT ciclver_ck CHECK(cicli_id>=1 AND cicli_id<=99999 AND UPPER(carrera_ver2)=carrera_ver2 AND REGEXP_LIKE(carrera_ver2,'^([A-Z0-9]*)$'));

ALTER TABLE registro ADD CONSTRAINT registro_ck CHECK(numero>=1 AND numero<=99999 AND tiempo>0 AND (dificultad='A' OR dificultad='M' OR dificultad='B')  AND c_registro>=1 AND c_registro<=99999 AND UPPER(ver_registro)=ver_registro AND REGEXP_LIKE(ver_registro,'^([A-Z0-9]*)$'));
ALTER TABLE foto ADD CONSTRAINT foto_ck CHECK(numero>=1 AND numero<=99999 AND direccion LIKE('www.%') AND (direccion LIKE('%.gif') OR direccion LIKE('%.pdf')));

/*Primarias*/
ALTER TABLE carrera ADD CONSTRAINT carrera_pk PRIMARY KEY (codigo);
ALTER TABLE punto ADD CONSTRAINT punto_pk PRIMARY KEY (punto_carrera);
ALTER TABLE propiedad_de ADD CONSTRAINT propiedad_de_pk PRIMARY KEY (propieterio,carrera_cod);

ALTER TABLE versioon ADD CONSTRAINT versioon_pk PRIMARY KEY (carrera_ver);
ALTER TABLE segmento ADD CONSTRAINT segmento_pk PRIMARY KEY (nombre);

ALTER TABLE miembro ADD CONSTRAINT miembro_pk PRIMARY KEY (idd);
ALTER TABLE persona ADD CONSTRAINT persona_pk PRIMARY KEY (persona_id);
ALTER TABLE empresa ADD CONSTRAINT empresa_pk PRIMARY KEY (empresa_id);
ALTER TABLE ciclista ADD CONSTRAINT ciclista_pk PRIMARY KEY (ciclista_id);
ALTER TABLE empver ADD CONSTRAINT empver_pk PRIMARY KEY (empre_id,carrera_ver1);
ALTER TABLE ciclver ADD CONSTRAINT ciclver_pk PRIMARY KEY (cicli_id,carrera_ver2);

ALTER TABLE registro ADD CONSTRAINT registro_pk PRIMARY KEY (numero);
ALTER TABLE foto ADD CONSTRAINT  foto_pk PRIMARY KEY (numero);

/*Unicas*/
ALTER TABLE registro ADD CONSTRAINT comentario_uk UNIQUE (comentario);

ALTER TABLE miembro ADD CONSTRAINT correo_uk UNIQUE (correo);

/*Foraneas*/
ALTER TABLE punto ADD CONSTRAINT punto_carrera_fk FOREIGN KEY(punto_carrera) REFERENCES carrera(codigo);
ALTER TABLE propiedad_de ADD CONSTRAINT carrera_cod_fk FOREIGN KEY(carrera_cod) REFERENCES carrera(codigo);
ALTER TABLE propiedad_de ADD CONSTRAINT propietario_fk FOREIGN KEY(propieterio) REFERENCES miembro(idd);

ALTER TABLE versioon ADD CONSTRAINT carrera_ver_fk FOREIGN KEY(carrera_ver) REFERENCES carrera(codigo);
ALTER TABLE segmento ADD CONSTRAINT seg_version_fk FOREIGN KEY(seg_version) REFERENCES versioon(carrera_ver);
ALTER TABLE segmento ADD CONSTRAINT punto_ini_fk FOREIGN KEY(punto_ini) REFERENCES punto(punto_carrera);
ALTER TABLE segmento ADD CONSTRAINT punto_fin_fk FOREIGN KEY(punto_fin) REFERENCES punto(punto_carrera);

ALTER TABLE persona ADD CONSTRAINT persona_id_fk FOREIGN KEY(persona_id) REFERENCES miembro(idd);
ALTER TABLE empresa ADD CONSTRAINT empresa_id_fk FOREIGN KEY(empresa_id) REFERENCES miembro(idd);
ALTER TABLE empresa ADD CONSTRAINT persona_idd_fk FOREIGN KEY(persona_idd) REFERENCES persona(persona_id);
ALTER TABLE ciclista ADD CONSTRAINT ciclista_id_fk FOREIGN KEY(ciclista_id) REFERENCES persona(persona_id);
ALTER TABLE empver ADD CONSTRAINT empre_id_fk FOREIGN KEY(empre_id) REFERENCES empresa(empresa_id);
ALTER TABLE empver ADD CONSTRAINT carrera_ver1_fk FOREIGN KEY(carrera_ver1) REFERENCES versioon(carrera_ver);
ALTER TABLE ciclver ADD CONSTRAINT cicli_id_fk FOREIGN KEY(cicli_id) REFERENCES ciclista(ciclista_id);
ALTER TABLE ciclver ADD CONSTRAINT carrera_ver2_fk FOREIGN KEY(carrera_ver2) REFERENCES versioon(carrera_ver);

ALTER TABLE registro ADD CONSTRAINT c_registro_fk FOREIGN KEY(c_registro) REFERENCES ciclista(ciclista_id);
ALTER TABLE registro ADD CONSTRAINT ver_registro_fk FOREIGN KEY(ver_registro) REFERENCES versioon(carrera_ver);
ALTER TABLE registro ADD CONSTRAINT seg_registro_fk FOREIGN KEY(seg_registro) REFERENCES segmento(nombre);
ALTER TABLE foto ADD CONSTRAINT direccion_fk FOREIGN KEY(numero) REFERENCES registro(numero);

/*PoblarNoOK*/
INSERT INTO carrera VALUES('ds45','los pollitos','COLOMBIA',4,'A');/*El codigo de carrera no debe tener minusculas*/
INSERT INTO miembro VALUES(457,'CC',7564845544,'COLOMBIA14','pepo@gmail.com');/*El pais solo debe ser alfabetico*/
INSERT INTO miembro VALUES(456,'CC',87867676667,'COLOMBIA','pepo@');/*El correo del miembro debe tener caracteres despues del '@'*/
INSERT INTO punto VALUES('ds45',4,'mariquita','M',6320.25,-9);/*El tiempo limite debe ser postivo*/
INSERT INTO miembro VALUES(40,'CC',1234,'COLOMBIA','sonris@hotmail.com');/*La dientificacion tiene que ser mayor a 11111111111*/

INSERT INTO carrera VALUES ('xh4voT', 'Vale', 'Colombia', 1, 'S');/*El codigo no puede contener minusculas*/
INSERT INTO miembro VALUES(100000,'CC',1234,'COLOMBIA','sonris@hotmail.com');/*Lel id no puede ser mayor a 99999*/
INSERT INTO foto VALUES(6,'www.fafa');/*La direccion de la imagen debe terminar en .gif o en .pdf*/
INSERT INTO carrera VALUES('SDF4','LaRutaSabana','COLOMBIA',9,'anual');/*El valor de categoria debe estar entre 1 y 5*/
INSERT INTO punto VALUES('LRS',101,'cajica','C',4577.25,345);/*El valor del porcentaje debe estar entre 1 y 100*/