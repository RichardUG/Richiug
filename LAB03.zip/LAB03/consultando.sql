/*consultar ciclistas*/
SELECT pais_m,COUNT(*) FROM miembro,persona,ciclista
WHERE idd=persona_id AND persona_id=ciclista_id
GROUP BY pais_m
ORDER BY pais_m ASC;

/*Consultar puntos*/
SELECT punto.nombre,tiempo_limite FROM punto
WHERE rownum<=5
ORDER BY tiempo_limite ASC;

/*Consultar segmentos de monta�a con secciones de descenso*/
SELECT versioon.nombre,segmento.nombre,COUNT(registro.numero) 
FROM carrera JOIN versioon ON codigo=carrera_ver JOIN segmento ON carrera_ver=seg_version JOIN registro ON segmento.nombre=seg_registro
GROUP BY versioon.nombre,segmento.nombre;

/*Consultar los cinco segmentos con tiempos mas cortos*/
SELECT versioon.nombre,persona.nombre,registro.posicion,registro.tiempo 
FROM persona JOIN ciclista ON persona.persona_id=ciclista.ciclista_id JOIN registro ON ciclista.ciclista_id=registro.c_registro JOIN versioon ON registro.ver_registro=versioon.carrera_ver
ORDER BY registro.tiempo ASC;

/*Consultar puntos de una carrera */
SELECT punto.nombre,punto.tipo,punto.distancia,punto.tiempo_limite FROM carrera JOIN punto ON carrera.codigo=punto.punto_carrera
ORDER BY punto.distancia;  