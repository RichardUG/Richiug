/*PoblarOK*/
INSERT INTO carrera VALUES('AAS45','los pollitos','COLOMBIA',4,'A');
INSERT INTO carrera VALUES('GT89','los alpes','COLOMBIA',3,'T');
INSERT INTO carrera VALUES('HJ45','la curva','COLOMBIA',4,'A');

INSERT INTO miembro VALUES(798,'CC',14911441561,'COLOMBIA','pepito@gmail.com');
INSERT INTO miembro VALUES(123,'CE',54756484554,'ARGENTINA','juan16@gmail.com');
INSERT INTO miembro VALUES(545,'CC',12345678910,'COLOMBIA','srgio1994@hotmail.com');
INSERT INTO miembro VALUES(400,'NT',12345678910,'COLOMBIA','corazon@hotmail.com');
INSERT INTO miembro VALUES(401,'NT',12345678910,'COLOMBIA','manitas@hotmail.com');
INSERT INTO miembro VALUES(402,'NT',12345678910,'COLOMBIA','sonrisas@hotmail.com');

INSERT INTO propiedad_de VALUES(798,'AAS45',79);
INSERT INTO propiedad_de VALUES(123,'AAS45',98);
INSERT INTO propiedad_de VALUES(545,'HJ45',76);

INSERT INTO punto VALUES('AAS45',49,'chia','C',4577.25,345);
INSERT INTO punto VALUES('GT89',44,'boyaca','M',5789.25,400);
INSERT INTO punto VALUES('HJ45',4,'mariquita','M',6320.25,444);

INSERT INTO versioon VALUES('AAS45','ch45',TO_DATE('2019/01/18','yyyy/mm/dd'));
INSERT INTO versioon VALUES('GT89','by47',TO_DATE('2019/09/17','yyyy/mm/dd'));
INSERT INTO versioon VALUES('HJ45','mr78',TO_DATE('2019/03/17','yyyy/mm/dd'));

INSERT INTO segmento VALUES('la rampa','AAS45','C','AAS45','AAS45');
INSERT INTO segmento VALUES('la bajada','GT89','M','GT89','GT89');
INSERT INTO segmento VALUES('campo','HJ45','M','HJ45','HJ45');

INSERT INTO persona VALUES(798,'Pepito perez');
INSERT INTO persona VALUES(123,'Daniel Orozco');
INSERT INTO persona VALUES(545,'Ramon Valdez');

INSERT INTO empresa VALUES(400,'Apoyo a los mas necesitados',798);
INSERT INTO empresa VALUES(401,'Escuelas para ni�os de escasos recursos',123);
INSERT INTO empresa VALUES(402,'Apoyo a personas con deficiencias cognitivas',545);

INSERT INTO empver VALUES(400,'AAS45');
INSERT INTO empver VALUES(401,'AAS45');
INSERT INTO empver VALUES(402,'AAS45');

INSERT INTO ciclista VALUES(798,TO_DATE('1995/08/26','yyyy/mm/dd'),4);
INSERT INTO ciclista VALUES(123,TO_DATE('1990/05/06','yyyy/mm/dd'),4);
INSERT INTO ciclista VALUES(545,TO_DATE('1999/11/16','yyyy/mm/dd'),4);

INSERT INTO ciclver VALUES(798,'AAS45');
INSERT INTO ciclver VALUES(123,'AAS45');
INSERT INTO ciclver VALUES(545,'AAS45');

INSERT INTO registro VALUES(1,TO_DATE('2018/08/26 09:53','YYYY/MM/DD HH24:MI'),294,1,NULL,'M',545,'AAS45','la rampa','Mantener nivel');
INSERT INTO registro VALUES(2,TO_DATE('2019/01/05 11:48','yyyy/mm/dd hh24:mi'),333,14,'velocidad minima 6km/h, velocidad maxima 13km/h, 95 pulsaciones promedio','A',123,'AAS45','la rampa',NULL);
INSERT INTO registro VALUES(3,TO_DATE('2018/12/26 07:32','yyyy/mm/dd hh24:mi'),321,7,NULL,'A',798,'AAS45','la rampa','Falta de aire');

INSERT INTO foto VALUES(1,NULL);
INSERT INTO foto VALUES(2,NULL);
INSERT INTO foto VALUES(3,'www.gifmania.com/Gif-Animados-Deportes/Imagenes-Ciclismo/Ciclistas/Ciclista-87408.gif');

/*PoblarNoOK*/
INSERT INTO miembro VALUES('NULL','CC',756484554,'COLOMBIA','pepito@gmail.com');/*El idd del miembro no puede ser NULL*/
INSERT INTO carrera VALUES(NULL,'los pollitos','COLOMBIA',4,'A');/*El codigo de carrera no puede ser de tipo NULL*/
INSERT INTO persona VALUES(798,'Pepito perez');/*El idpersona del miembro esta repetido*/
INSERT INTO persona VALUES(738,NULL);/*El nombre de la persona no puede ser de tipo NULL*/
INSERT INTO registro VALUES('1',NULL,358,2,NULL,'M',NULL,798,'AAS45','La curva',NULL);/*El numero del registro tiene que ser de tipo numerico y entero la fecha no puede ser de tipo NULL*/

INSERT INTO carrera VALUES('ds45','los pollitos','COLOMBIA',4,'A');/*El codigo de carrera no debe tener minusculas*/
INSERT INTO miembro VALUES(457,'CC',7564845544,'COLOMBIA14','pepo@gmail.com');/*El pais solo debe ser alfabetico*/
INSERT INTO miembro VALUES(456,'CC',87867676667,'COLOMBIA','pepo@');/*El correo del miembro debe tener caracteres despues del '@'*/
INSERT INTO punto VALUES('ds45',4,'mariquita','M',6320.25,-9);/*El tiempo limite debe ser postivo*/
INSERT INTO miembro VALUES(40,'CC',1234,'COLOMBIA','sonris@hotmail.com');/*La dientificacion tiene que ser mayor a 11111111111*/

/*XPoblar*/
DELETE FROM foto;
DELETE FROM registro;
DELETE FROM ciclver;
DELETE FROM ciclista;
DELETE FROM empver;
DELETE FROM empresa;
DELETE FROM persona;
DELETE FROM segmento;
DELETE FROM versioon;
DELETE FROM punto;
DELETE FROM propiedad_de;
DELETE FROM miembro;
DELETE FROM carrera;